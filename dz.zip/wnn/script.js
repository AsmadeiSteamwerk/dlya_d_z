let fs = require("fs");

fs.readFile("database.txt", "utf-8", function(err, content){

});

fs.writeFile("database.txt", content);

let dictionary = content;

let string = JSON.stringify(dictionary);
string

JSON.parse(string)