let express = require("express"),
bodyParcser= require("body-parser");

let app = express();
let urlencodedParser = bodyParser.urlencoded({extended: false});

app.post("/enroll", urlencodedParser, function(request, response) {

});

app.use(express.static("../client"));

let database;
app.get("/query", function(request, response) {
let depot = database.collection("depot");
response.redirect("/records.html")
})

mongoClient.connect(url, function(err, db) {
    database = db;
    app.listen(591);
});
